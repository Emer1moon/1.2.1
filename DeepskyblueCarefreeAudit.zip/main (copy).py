import turtle
import random

# Set up the screen
screen = turtle.Screen()
screen.bgcolor("black")  # Set background color to black for better contrast

# Create a turtle for the star spiral
star_spiral = turtle.Turtle()
star_spiral.speed(0)  # Fastest speed for quick drawing

# List of cool colors (blue, green, cyan, purple shades)
cool_colors = ["blue", "green", "cyan", "purple", "dark blue", "light blue", "teal", "indigo"]

# Initial parameters for shape size and movement
shape_size = 1  # Start with small shapes
move_distance = 5  # Initial move distance to create a tight starting pattern

# Draw the expanding spiral with a star-like pattern using cool colors
for i in range(100):  # Increase the range to make the star shape more detailed
    star_spiral.color(random.choice(cool_colors))  # Choose a random cool color for each step
    star_spiral.shape("triangle")  # Use triangles for a star-like shape
    star_spiral.shapesize(shape_size / 10)  # Dynamically adjust shape size

    # Stamp the triangle shape at the current position
    star_spiral.stamp()

    # Increase the shape size and move distance to create the expanding effect
    shape_size += 1  # Shapes get larger as the spiral expands
    move_distance += 2  # Increase distance for outward expansion

    # Move the turtle forward and create a star-like turn angle
    star_spiral.forward(move_distance)
    star_spiral.right(144)  # Angle to create a star pattern

# Hide the turtle after drawing is complete
star_spiral.hideturtle()

# Keep the window open until closed by the user
screen.mainloop()