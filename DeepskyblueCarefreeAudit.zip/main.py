# Importing turtle and random
import turtle as trtl
import random

# Creating lists for different shapes and colors
shapes = ["triangle", "circle", "square", "classic"]
colors = ["gold", "purple", "blue", "red", "yellow", "pink"]

# Setting up the turtle
t = trtl.Turtle()
t.speed(1000)

# Initializing variables for movement
distance = 0
angle = 0
t.setheading(angle)

# Conditional while loop to check whether the distance is less than 300
while distance < 300:
    # Randomly choose a new shape and color each time the turtle moves
    new_shape = random.choice(shapes)
    new_color = random.choice(colors)

    # Apply the new shape and color to the turtle
    t.shape(new_shape)
    t.fillcolor(new_color)
    t.pencolor(new_color)

    # Draw the shape and move the turtle forward
    t.penup()
    t.pendown()
    t.stamp()
    t.forward(distance)
    t.right(50)

    # Increment the distance for the next iteration
    distance += 5

# Keep the screen open
wn = trtl.Screen()
wn.mainloop()
